# Sagar Bhatta personal website — Cloudflare Pages

A responsive personal website with About, Creations, Portfolio, an email-allowlisted Google OAuth admin dashboard, CMS for blogs/updates/research/innovations/photos/videos, configurable animation/background styles, R2 media uploads, D1 content storage, and optional Cloudflare Workers AI.

## Project files

- `index.html`, `styles.css`, `app.js`: public website.
- `admin.html`, `admin.js`: admin interface at `/admin`.
- `functions/api/[[path]].js`: Pages Functions API (login, content, projects, creations, AI).
- `migrations/0001_initial.sql`: base D1 tables and starter profile text.
- `migrations/0002_cms.sql`: CMS content types and appearance preferences.
- `wrangler.toml`: Cloudflare Pages / D1 / Workers AI configuration template.

## Deploy using the Cloudflare dashboard (recommended)

1. Extract this ZIP. Create a GitHub repository and add the project files, but do not deploy until you have configured the D1 ID below.
2. In Cloudflare Dashboard, open **Storage & databases → D1 SQL Database → Create database**. Name it `sagar-bhatta-site`.
3. Copy the database ID from D1. Open `wrangler.toml` and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with that exact ID. Commit the change to your repository.
4. In the D1 database, open **Console** and execute both migration files in order: `migrations/0001_initial.sql`, then `migrations/0002_cms.sql`. This creates the CMS table and appearance settings.
5. In Cloudflare Dashboard, open **Workers & Pages → Create → Pages → Connect to Git** and select the repository. Use the repository root (`.`) as the build output directory and leave the build command blank.
6. In the Pages project, open **Settings → Bindings** and verify that a D1 database binding named `DB` points to your database. Also enable the **Workers AI** binding named `AI` if your project settings require it. The included `wrangler.toml` is a configuration template; configure bindings in the dashboard or via Wrangler, but avoid configuring the same binding twice.
7. Configure Google OAuth in Google Cloud Console. Create an OAuth Client ID for a Web application and add your site origin as an authorized JavaScript origin. Add this exact redirect URI: `https://YOUR-DOMAIN/api/auth/callback`. In Cloudflare Pages **Settings → Variables and Secrets**, add encrypted secrets `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `SESSION_SECRET` (32+ random bytes; generate with `openssl rand -hex 32`). The server accepts only the verified Google email `sagarbhatta593@gmail.com`.
8. For uploads, create an R2 bucket named `sagar-bhatta-media` or change the name in `wrangler.toml`, then bind it to the Pages project as `MEDIA_BUCKET`. R2 uploads are limited to 20 MB and allow JPEG, PNG, WebP, GIF, MP4 and WebM.
9. Save settings and redeploy. Visit `/admin`, use Google sign-in with the allowlisted account, and manage CMS content, uploads and appearance settings.

## Wrangler CLI alternative

Install Node.js and Wrangler, then log in:

```sh
npm install -g wrangler
wrangler login
wrangler d1 create sagar-bhatta-site
```

Copy the returned database ID into `wrangler.toml`. Apply the schema remotely:

```sh
wrangler d1 execute sagar-bhatta-site --remote --file=migrations/0001_initial.sql
```

For local development, copy `.dev.vars.example` to `.dev.vars` and replace both values. Never commit `.dev.vars`.

```sh
npx wrangler pages dev .
```

Deploy with your Pages project name after binding configuration:

```sh
npx wrangler pages deploy . --project-name=sagar-bhatta-personal
```

Set secrets `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `SESSION_SECRET` through the Cloudflare dashboard or Wrangler. Configure `DB`, optional `AI`, and `MEDIA_BUCKET` bindings in Pages settings. For OAuth, configure the exact redirect URI `https://YOUR-DOMAIN/api/auth/callback` in the Google Cloud OAuth client.

## Security and operating notes

- The admin API requires an HMAC-signed, eight-hour bearer token. The admin password and signing secret are server-side secrets; never put them in HTML or JavaScript.
- Keep `GOOGLE_CLIENT_SECRET` and `SESSION_SECRET` private. If a secret is exposed, rotate it immediately.
- Add Cloudflare rate limiting/WAF rules for `/api/login` and `/api/ai` before public production use. This starter does not implement a durable per-IP rate limiter.
- AI availability and billing/quota depend on your Cloudflare account and model availability. The app uses `@cf/meta/llama-3.1-8b-instruct`; change the model in `functions/api/[[path]].js` if your account no longer offers it.
- Public content is intentionally public. Do not store private personal data here.
- CMS media upload requires an R2 bucket binding. External media links are also supported. Content drafts are not exposed to public endpoints.
