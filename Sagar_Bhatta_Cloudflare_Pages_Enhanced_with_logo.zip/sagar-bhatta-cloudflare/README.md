# Sagar Bhatta Personal Website (Cloudflare Pages)

Personal portfolio with a CMS admin panel secured by Google OAuth allowlisting `sagarbhatta593@gmail.com`, blogs, updates, research, innovations, photo/video media, captions, drafts, publishing, editable profile, background styles and motion preferences.

See `DEPLOYMENT.md` for D1 migrations, OAuth, R2, secrets and deployment instructions.
