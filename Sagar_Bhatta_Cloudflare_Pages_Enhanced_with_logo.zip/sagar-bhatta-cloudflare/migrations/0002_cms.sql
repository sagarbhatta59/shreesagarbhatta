CREATE TABLE IF NOT EXISTS cms_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 kind TEXT NOT NULL DEFAULT 'blog',
 title TEXT NOT NULL,
 category TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT '',
 caption TEXT NOT NULL DEFAULT '',
 media_url TEXT NOT NULL DEFAULT '',
 url TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'draft',
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS cms_kind_status_idx ON cms_items(kind,status);
INSERT OR IGNORE INTO site_content(key,value) VALUES
 ('backgroundStyle','paper'),('textAnimation','fade-up'),('ambientMotion','on');
